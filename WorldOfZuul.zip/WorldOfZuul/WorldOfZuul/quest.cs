namespace SkyGarden;

public class Quest
{
    public string Name { get; }
    public string Neighbour { get; }
    public string Status { get; private set; }

    public Quest(string name, string neighbour)
    {
        Name = name;
        Neighbour = neighbour;
        Status = "Scheduled";
    }

    public void Launch()
    {
        Status = "Launched";
        Console.WriteLine($"Quest {Name} to {Neighbour} has been {Status}!");
    }

    public void Abort()
    {
        Status = "Aborted";
        Console.WriteLine($"Quest {Name} to {Neighbour} has been {Status}!");
    }
}